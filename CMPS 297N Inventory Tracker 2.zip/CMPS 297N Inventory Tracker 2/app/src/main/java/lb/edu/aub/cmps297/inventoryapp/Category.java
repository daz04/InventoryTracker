package lb.edu.aub.cmps297.inventoryapp;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.annotation.NonNull;

/**
 * Entity class that represents an inventory in the database
 * which contains categories and items
 */

@Entity(tableName = "cat_table")
public class Category {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @NonNull
    @ColumnInfo(name = "category")
    private String mCat;

    public Category(@NonNull String cat) {

        this.mCat = cat;
    }

    /*
     * This constructor is annotated using @Ignore, because Room expects only
     * one constructor by default in an entity class.
     */

    @Ignore
    public Category(int id, @NonNull String cat) {
        this.id = id;
        this.mCat = cat;
    }

    public String getCat() { return this.mCat; }

    public int getId() {return id;}

    public void setId(int id) {
        this.id = id;
    }
}

