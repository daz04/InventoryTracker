package lb.edu.aub.cmps297.inventoryapp;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

// Maria Hajj
/**
 * Data Access Object (DAO) for a category.
 * Each method performs a database operation, such as inserting or deleting a category,
 * running a DB query, or deleting all categories.
 */

@Dao
public interface CatDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Category cat);

    @Query("DELETE FROM cat_table")
    void deleteAll();

    @Delete
    void deleteCat(Category cat);

    @Query("SELECT * from cat_table LIMIT 1")
    Category[] getAnyCat();

    @Query("SELECT * from cat_table ORDER BY category ASC")
    LiveData<List<Category>> getAllCat();

    @Update
    void update(Category... cat);
}
