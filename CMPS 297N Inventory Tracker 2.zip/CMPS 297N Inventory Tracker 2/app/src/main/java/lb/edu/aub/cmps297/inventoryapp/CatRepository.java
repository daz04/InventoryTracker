package lb.edu.aub.cmps297.inventoryapp;

import android.app.Application;
import android.os.AsyncTask;

import java.util.List;

import androidx.lifecycle.LiveData;

/**
 * This class holds the implementation code for the methods that interact with the database.
 * Using a repository allows us to group the implementation methods together,
 * and allows the CatViewModel to be a clean interface between the rest of the app
 * and the database.
 *
 * For insert, update and delete, and longer-running queries,
 * you must run the database interaction methods in the background.
 *
 * Typically, all you need to do to implement a database method
 * is to call it on the data access object (DAO), in the background if applicable.
 */

public class CatRepository {

    private CatDao mCatDao;
    private LiveData<List<Category>> mAllCats;

    CatRepository(Application application) {
        CategoryRoomDatabase db = CategoryRoomDatabase.getDatabase(application);
        mCatDao = db.catDao();
        mAllCats = mCatDao.getAllCat();
    }

    LiveData<List<Category>> getAllCats() {
        return mAllCats;
    }

    public void insert(Category category) {
        new insertAsyncTask(mCatDao).execute(category);
    }

    public void update(Category category)  {
        new updateCatAsyncTask(mCatDao).execute(category);
    }

    public void deleteAll()  {
        new deleteAllCatsAsyncTask(mCatDao).execute();
    }

    // Must run off main thread
    public void deleteCat(Category category) { new deleteCatAsyncTask(mCatDao).execute(category); }

    // Static inner classes below here to run database interactions in the background.

    /**
     * Inserts a category into the database.
     */
    private static class insertAsyncTask extends AsyncTask<Category, Void, Void> {

        private CatDao mAsyncTaskDao;

        insertAsyncTask(CatDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final Category... params) {
            mAsyncTaskDao.insert(params[0]);
            return null;
        }
    }

    /**
     * Deletes all categories from the database (does not delete the table).
     */
    private static class deleteAllCatsAsyncTask extends AsyncTask<Void, Void, Void> {
        private CatDao mAsyncTaskDao;

        deleteAllCatsAsyncTask(CatDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            mAsyncTaskDao.deleteAll();
            return null;
        }
    }

    /**
     *  Deletes a single categories from the database.
     */
    private static class deleteCatAsyncTask extends AsyncTask<Category, Void, Void> {
        private CatDao mAsyncTaskDao;

        deleteCatAsyncTask(CatDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final Category... params) {
            mAsyncTaskDao.deleteCat(params[0]);
            return null;
        }
    }

    /**
     *  Updates a category in the database.
     */
    private static class updateCatAsyncTask extends AsyncTask<Category, Void, Void> {
        private CatDao mAsyncTaskDao;

        updateCatAsyncTask(CatDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final Category... params) {
            mAsyncTaskDao.update(params[0]);
            return null;
        }
    }
}
