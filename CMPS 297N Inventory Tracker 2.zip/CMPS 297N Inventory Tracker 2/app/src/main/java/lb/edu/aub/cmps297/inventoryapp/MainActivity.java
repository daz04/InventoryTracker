package lb.edu.aub.cmps297.inventoryapp;

// Maria Hajj
// Main code for the first page which is the categories page

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.List;

/**
 * This class displays a list of categories in a RecyclerView.
 * The categories are saved in a Room database.
 * The layout for this activity also displays an add category button that
 * allows users to start the AddCatActivity to add new categories.
 * Users can delete a category by swiping to the left.
 * Whenever a new category is added, deleted, or updated, the RecyclerView
 * showing the list of categories automatically updates.
 */

public class MainActivity extends AppCompatActivity {

    public static final int NEW_CAT_ACTIVITY_REQUEST_CODE = 1;
    public static final int UPDATE_CAT_ACTIVITY_REQUEST_CODE = 2;

    public static final String EXTRA_DATA_UPDATE_CAT = "extra_cat_to_be_updated";
    public static final String EXTRA_DATA_ID = "extra_data_id";

    private CatViewModel mCatViewModel;

    Button addBtn;
    Button inventoryBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set up the RecyclerView.
        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        final CatListAdapter adapter = new CatListAdapter(this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Set up the CatViewModel.
        mCatViewModel = ViewModelProviders.of(this).get(CatViewModel.class);
        // Get all the categories from the database
        // and associate them to the adapter.
        mCatViewModel.getAllCats().observe(this, new Observer<List<Category>>() {
            @Override
            public void onChanged(@Nullable final List<Category> cats) {
                // Update the cached copy of the categories in the adapter.
                adapter.setCats(cats);
            }
        });

        addBtn = findViewById(R.id.addItemButton);
        inventoryBtn = findViewById(R.id.inventoryButton);

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddCatActivity.class);
                startActivityForResult(intent, NEW_CAT_ACTIVITY_REQUEST_CODE);
            }
        });

        // Add the functionality to swipe items in the
        // RecyclerView to delete the swiped item.
        ItemTouchHelper helper = new ItemTouchHelper(
                new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
                    @Override
                    // We are not implementing onMove() in this app.
                    public boolean onMove(RecyclerView recyclerView,
                                          RecyclerView.ViewHolder viewHolder,
                                          RecyclerView.ViewHolder target) {
                        return false;
                    }

                    @Override
                    // When the user swipes a category,
                    // delete that category from the database.
                    public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                        int position = viewHolder.getAdapterPosition();
                        Category myCat = adapter.getCatAtPosition(position);
                        Toast.makeText(MainActivity.this,
                                getString(R.string.delete_cat_preamble) + " " +
                                        myCat.getCat(), Toast.LENGTH_LONG).show();

                        // Delete the category.
                        mCatViewModel.deleteCat(myCat);
                    }
                });
        // Attach the item touch helper to the recycler view.
        helper.attachToRecyclerView(recyclerView);

        adapter.setOnItemClickListener(new CatListAdapter.ClickListener()  {

            @Override
            public void onItemClick(View v, int position) {
                Category cat = adapter.getCatAtPosition(position);
                launchUpdateCatActivity(cat);
            }
        });

        inventoryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
                startActivity(intent);
            }
        });
    }

    /**
     * When the user enters a new category in the AddCatActivity,
     * that activity returns the result to this activity.
     * If the user entered a new category, save it in the database.

     * @param requestCode ID for the request
     * @param resultCode indicates success or failure
     * @param data The Intent sent back from the AddCatActivity,
     *             which includes the category that the user entered
     */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == NEW_CAT_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK) {
            Category cat = new Category(data.getStringExtra(AddCatActivity.EXTRA_REPLY));
            // Save the data.
            mCatViewModel.insert(cat);
        } else if (requestCode == UPDATE_CAT_ACTIVITY_REQUEST_CODE
                && resultCode == RESULT_OK) {
            String cat_data = data.getStringExtra(AddCatActivity.EXTRA_REPLY);
            int id = data.getIntExtra(AddCatActivity.EXTRA_REPLY_ID, -1);

            if (id != -1) {
                mCatViewModel.update(new Category(id, cat_data));
            } else {
                Toast.makeText(this, R.string.unable_to_update,
                        Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(
                    this, R.string.empty_not_saved, Toast.LENGTH_LONG).show();
        }
    }

    public void launchUpdateCatActivity(Category cat) {
        Intent intent = new Intent(this, AddCatActivity.class);
        intent.putExtra(EXTRA_DATA_UPDATE_CAT, cat.getCat());
        intent.putExtra(EXTRA_DATA_ID, cat.getId());
        startActivityForResult(intent, UPDATE_CAT_ACTIVITY_REQUEST_CODE);
    }
}