package lb.edu.aub.cmps297.inventoryapp;

import android.app.Application;

import java.util.List;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

/**
 * The CatViewModel provides the interface between the UI and the data layer of the app,
 * represented by the Repository
 */

public class CatViewModel extends AndroidViewModel {

    private CatRepository mRepository;

    private LiveData<List<Category>> mAllCats;

    public CatViewModel(Application application) {
        super(application);
        mRepository = new CatRepository(application);
        mAllCats = mRepository.getAllCats();
    }

    LiveData<List<Category>> getAllCats() {
        return mAllCats;
    }

    public void insert(Category category) {
        mRepository.insert(category);
    }

    public void deleteAll() {
        mRepository.deleteAll();
    }

    public void deleteCat(Category category) {
        mRepository.deleteCat(category);
    }

    public void update(Category category) {
        mRepository.update(category);
    }
}
