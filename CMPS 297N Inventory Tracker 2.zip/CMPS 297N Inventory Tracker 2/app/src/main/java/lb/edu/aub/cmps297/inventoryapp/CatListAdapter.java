package lb.edu.aub.cmps297.inventoryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;

/**
 * Adapter for the RecyclerView that displays a list of categories.
 */

public class CatListAdapter extends RecyclerView.Adapter<CatListAdapter.CatViewHolder> {

    private final LayoutInflater mInflater;
    private List<Category> mCats; // Cached copy of categories
    private static ClickListener clickListener;

    CatListAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
    }

    @Override
    public CatViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.recyclerview_itemcat, parent, false);
        return new CatViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(CatViewHolder holder, int position) {
        if (mCats != null) {
            Category current = mCats.get(position);
            holder.catItemView.setText(current.getCat());
        } else {
            // Covers the case of data not being ready yet.
            holder.catItemView.setText(R.string.no_cat);
        }
    }

    /**
     * Associates a list of categories with this adapter
     */

    void setCats(List<Category> cats) {
        mCats = cats;
        notifyDataSetChanged();
    }

    /**
     * getItemCount() is called many times, and when it is first called,
     * mCats has not been updated (means initially, it's null, and we can't return null).
     */

    @Override
    public int getItemCount() {
        if (mCats != null)
            return mCats.size();
        else return 0;
    }

    /**
     * Gets the category at a given position.
     * This method is useful for identifying which category
     * was clicked or swiped in methods that handle user events.
     *
     * @param position The position of the category in the RecyclerView
     * @return The category at the given position
     */

    public Category getCatAtPosition(int position) {
        return mCats.get(position);
    }

    class CatViewHolder extends RecyclerView.ViewHolder {
        private final TextView catItemView;

        private CatViewHolder(View itemView) {
            super(itemView);
            catItemView = itemView.findViewById(R.id.textView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    clickListener.onItemClick(view, getAdapterPosition());
                }
            });
        }
    }

    public void setOnItemClickListener(ClickListener clickListener) {
        CatListAdapter.clickListener = clickListener;
    }

    public interface ClickListener {
        void onItemClick(View v, int position);
    }

}
