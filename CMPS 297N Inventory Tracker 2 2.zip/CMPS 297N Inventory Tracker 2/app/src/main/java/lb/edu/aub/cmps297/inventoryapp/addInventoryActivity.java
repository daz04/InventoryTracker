package lb.edu.aub.cmps297.inventoryapp;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import static lb.edu.aub.cmps297.inventoryapp.MainActivity.EXTRA_DATA_ID;
import static lb.edu.aub.cmps297.inventoryapp.MainActivity.EXTRA_DATA_UPDATE_ITEM;

import java.util.ArrayList;

public class addInventoryActivity extends AppCompatActivity{
    ImageView inventoryBtn;
    TextView backBtn;
    TextView label;
    Button increment;
    Button decrement;
    ImageView delete;
    public static final int PICK_IMAGE = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addinventory);



        inventoryBtn = findViewById(R.id.backarrow);
        delete = findViewById(R.id.trashCan);
        backBtn = findViewById(R.id.Back);
        label = findViewById(R.id.labelText);
        increment = findViewById(R.id.increase);
        decrement = findViewById(R.id.decrease);
        ImageView itemImage = findViewById(R.id.productImage);

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(addInventoryActivity.this,InventoryActivity.class);
                startActivity(intent);


            }
        });
        increment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView counter = findViewById(R.id.integer_number);
                String counter_value = counter.getText().toString();
                int count_int = Integer.parseInt(counter_value);
                count_int = count_int +1;
                counter_value = Integer.toString(count_int);
                counter.setText(counter_value);


            }
        });
        decrement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView counter = findViewById(R.id.integer_number);
                String counter_value = counter.getText().toString();
                int count_int = Integer.parseInt(counter_value);
                count_int = count_int -1;
                counter_value = Integer.toString(count_int);
                counter.setText(counter_value);


            }
        });


        inventoryBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(addInventoryActivity.this,InventoryActivity.class);
                startActivity(intent);
            }
        });
        backBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String label_text = label.getText().toString();
                if (label_text != ""){
                    ItemViewModel itemViewModel = new ItemViewModel(getApplication());

                    TextView description = findViewById(R.id.description_input);
                    TextView location = findViewById(R.id.locationInput);
                    TextView notes = findViewById(R.id.integer_number);
                    TextView count = findViewById(R.id.integer_number);
                    ImageView image = findViewById(R.id.productImage);
                    Drawable drawable = image.getDrawable();
                    String imageUri = "drawable://"+drawable.toString();



                    String desInput =description.getText().toString();
                    String locationInput = location.getText().toString();
                    String notesInput = notes.getText().toString();
                    String countInput = count.getText().toString();

                    Item newitem = new Item (label_text,desInput,locationInput,notesInput,countInput,imageUri);
                    itemViewModel.insert(newitem);




                }
                Intent intent = new Intent(addInventoryActivity.this,InventoryActivity.class);
                startActivity(intent);
            }
        });
        itemImage.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent,"Select Image"), PICK_IMAGE);

            }




        });


        


    }
    @Override
    protected  void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE){
            if (resultCode== RESULT_OK){
                Uri selectedImage = data.getData();
                String[] filePath = {MediaStore.Images.Media.DATA};


            }
        }
    }

}
