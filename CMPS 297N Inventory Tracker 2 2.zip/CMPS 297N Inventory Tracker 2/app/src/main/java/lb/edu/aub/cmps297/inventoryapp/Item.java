package lb.edu.aub.cmps297.inventoryapp;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.annotation.NonNull;

import org.json.JSONObject;

// Maria Hajj
/**
 * Entity class that represents an inventory in the database
 * which contains categories and items
 */

@Entity(tableName = "item_table")
public class Item {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @NonNull
    @ColumnInfo(name="label")
    private String label;
    @ColumnInfo(name = "description")
    private String description;
    @ColumnInfo (name="location")
    private String location;
    @ColumnInfo (name="notes")
    private String notes;
    @NonNull
    @ColumnInfo (name="quantity")
    private String quantity;
    @ColumnInfo (name="img")
    private String img_path;



    public Item (String label, String description, String location, String notes, String quantity, String img_path ) {


        this.label = label;
        this.description = description;
        this.location = location;
        this.notes = notes;
        this.quantity = quantity;
        this.img_path = img_path;
    }

    /*
     * This constructor is annotated using @Ignore, because Room expects only
     * one constructor by default in an entity class.
     */

    @Ignore
    public Item (int id, String[] attributes ) {
        this.id = id;
        this.label = attributes[0];
        this.description = attributes[1];
        this.location = attributes[2];
        this.notes = attributes[3];
        this.quantity = attributes[4];
        this.img_path = attributes[5];
    }




    public int getId() {return id;}

    public void setId(int id) {
        this.id = id;
    }
    public String getLabel() {return label;}
    public String getDescription() {return description;}
    public String getLocation() {return location;}
    public String getNotes() {return notes;}
    public String getQuantity(){return quantity;}
    public String getImg_path(){return  img_path;}
}
