package lb.edu.aub.cmps297.inventoryapp;

// Maria Hajj
// Code for the add category screen
// (appears when the "Add Category" button is clicked on the category screen)

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;

import static lb.edu.aub.cmps297.inventoryapp.MainActivity.EXTRA_DATA_ID;
import static lb.edu.aub.cmps297.inventoryapp.MainActivity.EXTRA_DATA_UPDATE_CAT;

/**
 * This class displays a screen where the user enters a new category.
 * The AddCatActivity returns the entered category to the calling activity
 * (MainActivity), which then stores the new category and updates the list of
 * displayed categories.
 */

public class AddCatActivity extends AppCompatActivity {

    public static final String EXTRA_REPLY = "lb.edu.aub.cmps297.inventoryapp.REPLY";
    public static final String EXTRA_REPLY_ID = "lb.edu.aub.cmps297.inventoryapp.REPLY_ID";

    Button sendAddBtn;
    Button btnCancel;
    EditText edit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_category_page);

        sendAddBtn = findViewById(R.id.buttonSend);
        btnCancel = findViewById(R.id.buttonCancel);
        edit = findViewById(R.id.addField);

        final Bundle extras = getIntent().getExtras();

        // If we are passed content, fill it in for the user to edit.
        if (extras != null) {
            String cat = extras.getString(EXTRA_DATA_UPDATE_CAT, "");
            if (!cat.isEmpty()) {
                edit.setText(cat);
                edit.setSelection(cat.length());
                edit.requestFocus();
            }
        } // Otherwise, start with empty fields.


        final Button button = findViewById(R.id.buttonSend);

        // When the user presses the Save button, create a new Intent for the reply.
        // The reply Intent will be sent back to the calling activity (in this case, MainActivity).
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                // Create a new Intent for the reply.
                Intent replyIntent = new Intent();
                if (TextUtils.isEmpty(edit.getText())) {
                    // No category was entered, set the result accordingly.
                    setResult(RESULT_CANCELED, replyIntent);
                } else {
                    // Get the new category that the user entered.
                    String cat = edit.getText().toString();
                    // Put the new category in the extras for the reply Intent.
                    replyIntent.putExtra(EXTRA_REPLY, cat);
                    if (extras != null && extras.containsKey(EXTRA_DATA_ID)) {
                        int id = extras.getInt(EXTRA_DATA_ID, -1);
                        if (id != -1) {
                            replyIntent.putExtra(EXTRA_REPLY_ID, id);
                        }
                    }
                    // Set the result status to indicate success.
                    setResult(RESULT_OK, replyIntent);
                }
                finish();
            }
        });
        // When cancel button is clicked go back to list of categories
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent resultIntent = new Intent();
                setResult(RESULT_CANCELED, resultIntent);
                finish();
            }
        });
    }
}