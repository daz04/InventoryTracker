package lb.edu.aub.cmps297.inventoryapp;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

// Maria Hajj

/**
 * Data Access Object (DAO) for an item.
 * Each method performs a database operation, such as inserting or deleting an item,
 * running a DB query, or deleting all items.
 */

@Dao
public interface ItemDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Item item);

    @Query("DELETE FROM item_table")
    void deleteAll();

    @Delete
    void deleteItem(Item item);

    @Query("SELECT * from item_table")
    Item[] getAnyItem();

    @Query("SELECT * from item_table ORDER BY id ASC")
    LiveData<List<Item>> getAllItems();

    @Update
    void update(Item... items);
}
