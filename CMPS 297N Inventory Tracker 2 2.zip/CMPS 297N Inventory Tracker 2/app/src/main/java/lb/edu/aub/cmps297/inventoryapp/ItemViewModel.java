package lb.edu.aub.cmps297.inventoryapp;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class ItemViewModel extends AndroidViewModel {
    private ItemRepository itemRepository;
    private LiveData<List<Item>> mallItems;

    public ItemViewModel(Application application){
        super(application);
        mallItems = itemRepository.getAllItems();

    }
    LiveData<List<Item>> getAllItems() {
        return mallItems;
    }

    public void insert(Item item) {
        itemRepository.insert(item);
    }

    public void deleteAll() {
        itemRepository.deleteAll();
    }

    public void deleteItem(Item item) {
        itemRepository.deleteItem(item);
    }

    public void update(Item item) {
        itemRepository.update(item);
    }

}
